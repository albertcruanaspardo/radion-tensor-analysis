# Suite 17-Layered Foliated Bulk Gravity

Analytic and numerical validation suite for the 17-layered foliated bulk, 8(+) vs 8(-) double octet balance (602.50 GeV radion), 3.33 TeV parity doublet in LHC, PeV neutrino inelastic absorption in IceCube, and 0.19 mHz GW stochastic background in LISA.

Author: Albert Cruanas Pardo (ORCID: 0009-0007-0846-2321)
DOI: 10.5281/zenodo.23135100
